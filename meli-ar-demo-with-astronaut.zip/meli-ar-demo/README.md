# Demo AR • Mercado Libre (WebAR + Deep Links)

Este paquete te deja listo para mostrar productos a escala real en AR (Android: Scene Viewer, iOS: Quick Look) usando una sola página: `ar.html`.

---

## 1) Estructura
```
meli-ar-demo/
  ar.html
  assets/
    logo_ml.svg
    poster.png            ← Póster/thumbnail en muy alta definición (3000x2000)
    sample.glb            ← Placeholder (reemplazar)
    sample.usdz           ← Placeholder (reemplazar)
  native/
    android_scene_viewer.kt
    ios_quicklook.swift
```

> **Importante:** Incluí `sample.glb/usdz` solo como *placeholders*. Para la demo real, sustituí por un **modelo conocido** (zapatilla popular).

---

## 2) Cómo usar (rápido)
1. Subí la carpeta a un hosting estático (GitHub Pages, Vercel, S3/CloudFront).
2. Conseguí un modelo 3D **de alta calidad** y **licencia compatible** en **GLB** y **USDZ**. 
   - Filtrá por “Downloadable/CC/royalty‑free” en tu repositorio de confianza.
3. Colocá los archivos en `assets/` y renombrá:
   - `assets/zapatilla.glb`
   - `assets/zapatilla.usdz`
   - (opcional) `assets/poster.png` en **muy alta definición** (recomendado 3000×2000 o más).
4. Abrí la URL:
```
https://TU_DOMINIO/ar.html?title=Zapatillas%20Pro&glb=https://TU_DOMINIO/assets/zapatilla.glb&usdz=https://TU_DOMINIO/assets/zapatilla.usdz&poster=https://TU_DOMINIO/assets/poster.png
```
5. Probá en:
   - **Android (Chrome)** → abre **Scene Viewer**.
   - **iOS (Safari)** → abre **Quick Look**.
   - **Desktop** → visor 3D con rotación y zoom.

---

## 3) Requisitos del modelo
- **Unidades en metros** (escala real).
- Geometría optimizada (hasta ~100K triángulos para fluidez).
- Texturas PBR de **alta resolución** (mín. 4K: baseColor, roughnessMetallic, normal).
- Centrado (0,0,0) y apoyado en Y=0 para colocación correcta en el piso.

**Poster (imagen previa)**
- 3000×2000 px o mayor.
- PNG/JPG de alta calidad.
- Peso recomendado: <1.5 MB (usa compresión adaptativa).

---

## 4) Deep links nativos (opcional para demo en app)
### Android (Scene Viewer)
- Ver `native/android_scene_viewer.kt`. Usa:
```
https://arvr.google.com/scene-viewer/1.0
  ?file=URL_GLTF_O_GLB
  &mode=ar_only
  &title=Zapatillas%20Pro
```
> Requiere `com.google.ar.core` instalado.

### iOS (Quick Look)
- Ver `native/ios_quicklook.swift`.
- Cargar el `.usdz` en un `QLPreviewController` o `ARQuickLookPreviewItem`.

---

## 5) Troubleshooting
- **iOS no abre AR**: confirmar que el URL **termina en `.usdz`** y el header `Content-Type: model/vnd.usdz+zip`.
- **Android no abre AR**: verificar que el dispositivo tiene **Google Play Services for AR**.
- **El objeto aparece muy grande/pequeño**: corregir la **escala** del modelo en Blender (1 unidad = 1 metro).
- **CORS**: habilitar GET públicos en tu CDN; evitar redirecciones 301/302 a los binarios GLB/USDZ.

---

## 6) Analytics (sugerencia)
Agregá eventos básicos:
- `ar_viewer_open` (platform)
- `ar_session_started` / `ar_failed`
- `time_in_viewer_sec`

---

## 7) Próximos pasos (opcional)
- Try‑on con seguimiento de pie (SDK especializado).
- Pipeline de ingestión masiva de modelos para sellers.
- Campo en backend con URLs GLB/USDZ por publicación y *feature flag* en app.


---

## 8) URL de demo lista (sin subir modelos)
Usa este link tal cual — el prototipo cargará el **Astronauta** (modelo conocido) hospedado por `modelviewer.dev` (GLB) y GitHub (USDZ):

```
https://TU_DOMINIO/ar.html?title=Astronauta&glb=https://modelviewer.dev/shared-assets/models/Astronaut.glb&usdz=https://raw.githubusercontent.com/google/model-viewer/master/packages/shared-assets/models/Astronaut.usdz&poster=https://modelviewer.dev/shared-assets/models/NeilArmstrong.webp
```

Si luego querés volver a zapatillas, sustituí `glb`, `usdz` y `poster` por los tuyos.
